#ifndef UART_H
#define UART_H

#include <stdint.h>

void uart2_init();
void uart2_transmit(uint8_t data);
void uart2_puts(char* message);
void uart3_init();
void uart3_transmit(uint8_t data);

#endif