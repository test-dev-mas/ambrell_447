#ifndef HD8357_H
#define HD8357_H

void write8_command(uint8_t command);
void write8_data(uint8_t data);
void hd8357_init();

#endif