#include <avr/io.h>
#include <util/delay.h>

#include "hd8357.h"

#define CS  PC2
#define CD  PC3
#define WR  PC0
#define RD  PC1
#define RST PC4

void write8_command(uint8_t command) {
    PORTC &= ~(1<<CS);
    PORTC &= ~(1<<CD);                      // data
    PORTA = command;                        // PORTA maps to D7...0
    PORTC |= (1<<WR);                       // strobe WR
    PORTC &= ~(1<<WR);
    PORTC |= (1<<CS);
}

void write8_data(uint8_t data) {
    PORTC &= ~(1<<CS);
    PORTC |= (1<<CD);                       // data
    PORTA = data;                           // PORTA maps to D7...0
    PORTC |= (1<<WR);                       // strobe WR
    PORTC &= ~(1<<WR);
    PORTC |= (1<<CS);
}

void hd8357_init() {
    DDRC |= (1<<CS) | (1<<CD) | (1<<WR) | (1<<RD) | (1<<RST);
    PORTC |= (1<<CS) | (1<<CD) | (1<<WR) | (1<<RD) | (1<<RST);

    DDRA = 0xFF;

    write8_command(0xB9);                   // enable extension command
    write8_data(0xFF);
    write8_data(0x83);
    write8_data(0x57);
    _delay_ms(250);

    write8_command(0xB3);                   // set RGB interface
    write8_data(0x00);
    write8_data(0x00);
    write8_data(0x06);
    write8_data(0x06);

    write8_command(0xB6);                   // set VCOM voltage
    write8_data(0x25);

    write8_command(0xB0);                   // set internal oscillator
    write8_data(0x68);

    write8_command(0xCC);                   // set panel characteristic register
    write8_data(0x05);

    write8_command(0xB1);                   // set power control
    write8_data(0x00);
    write8_data(0x15);
    write8_data(0x1C);
    write8_data(0x1C);
    write8_data(0x83);
    write8_data(0xAA);

    write8_command(0xC0);                   // set source circuit option
    write8_data(0x50);
    write8_data(0x50);
    write8_data(0x01);
    write8_data(0x3C);
    write8_data(0x1E);
    write8_data(0x08);

    write8_command(0xB4);                   //set display cycle register
    write8_data(0x02);
    write8_data(0x40);
    write8_data(0x00);
    write8_data(0x2A);
    write8_data(0x2A);
    write8_data(0x0D);
    write8_data(0x78);

    write8_command(0x3A);
    write8_data(0x55);

    write8_command(0x36);
    write8_data(0xC0);

    write8_command(0x35);
    write8_data(0x00);

    write8_command(0x44);
    write8_data(0x00);
    write8_data(0x02);

    write8_command(0x11);                   // sleep out
    _delay_ms(150);

    write8_command(0x29);                   // display on
    _delay_ms(50);

    write8_command(0x2A);                   // set column address
    write8_data(0x00);                      // start higher byte
    write8_data(0x00);                      // start lower byte
    write8_data(0x3F);                      // end higher byte
    write8_data(0x01);                      // end higher byte

    write8_command(0x2B);                   // set page address
    write8_data(0x00);
    write8_data(0x00);
    write8_data(0xDF);
    write8_data(0x01);

    write8_command(0x2C);                   // write to GRAM
    for (uint32_t i=0;i<1536;i++) {
        write8_data(0xA8);                  // write higher byte
        write8_data(0x8A);                  // write lower byte
    }

    // for (uint8_t i=0;i<5;i++) {
    //     write8_command(0x22);                   // all pixel off
    //     _delay_ms(250);
    //     write8_command(0x23);                   // all pixel on
    //     _delay_ms(250);
    // }

}