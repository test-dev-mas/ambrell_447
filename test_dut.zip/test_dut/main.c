#include <avr/io.h>
#include <util/delay.h>
#include <stdbool.h>

#include "hd8357.h"
#include "sd.h"
#include "spi.h"
#include "uart.h"

#define BLINK_MS    1000
#define J11_1       PH4     // J11 PIN 1
#define J10_1       PL0     // READY LED

int main() {
    DDRH = (1<<J11_1);
    DDRL = (1<<J10_1);
    // DDRB = (1<<PB5);

    hd8357_init();
    spi_init();
    uart2_init();
    uart3_init();
    sd_init();

    uint8_t res[5];
    char* message[] = {"on","off"};
    char* p = message[0];
    
    uint8_t j = 0;

    uart2_puts("Sending command0 ...\r\n");
    res[0] = sd_go_idle();
    sd_print_response(res);

    uart2_puts("Sending command8 ...\r\n");
    sd_send_if_cond(res);
    sd_print_response(res);
    
    while (true) {
        PORTH ^= (1<<J11_1);
        PORTL ^= (1<<J10_1);
        PORTC ^= (1<<PC0);                  // test WR pin for LCD display

        // spi_transfer(0xAA);
        
        while (*p) {
            uart3_transmit(*p++);
        }
        uart3_transmit('\r');

        // if (p == message[0]) {
        //     p = message[1];
        // }
        // else {
        //     p = message[0];
        // }
        if (j) {
            p = message[0];
            j = 0;
        }
        else {
            p = message[1];
            j = 1;
        }
        _delay_ms(BLINK_MS);
    }
}