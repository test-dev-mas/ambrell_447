#ifndef TEST_3A_H
#define TEST_3A_H

#include <Adafruit_GFX.h>       // Core graphics library
#include <Adafruit_TFTLCD.h>    // Hardware-specific library

bool test_3a(Adafruit_TFTLCD &tft, char* test_name);

#endif