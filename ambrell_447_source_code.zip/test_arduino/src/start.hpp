#ifndef START_H
#define START_H

#include <Adafruit_TFTLCD.h>    // Hardware-specific library

int start(Adafruit_TFTLCD &tft);

#endif