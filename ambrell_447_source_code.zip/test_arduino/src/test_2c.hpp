#ifndef TEST_2C_H
#define TEST_2C_H

#include <Adafruit_GFX.h>       // Core graphics library
#include <Adafruit_TFTLCD.h>    // Hardware-specific library

bool test_2c(Adafruit_TFTLCD &tft, char* test_name);

#endif