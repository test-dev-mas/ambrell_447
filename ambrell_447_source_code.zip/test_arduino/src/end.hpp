#ifndef END_H
#define END_H

#include <Adafruit_TFTLCD.h>    // Hardware-specific library

void end(Adafruit_TFTLCD &tft);

#endif