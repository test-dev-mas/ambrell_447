#ifndef TEST_2A_H
#define TEST_2A_H

#include <Adafruit_GFX.h>       // Core graphics library
#include <Adafruit_TFTLCD.h>    // Hardware-specific library

bool test_2a(Adafruit_TFTLCD &tft, char* test_name);

#endif