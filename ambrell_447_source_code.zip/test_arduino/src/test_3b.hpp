#ifndef TEST_3B_H
#define TEST_3B_H

#include <Adafruit_GFX.h>       // Core graphics library
#include <Adafruit_TFTLCD.h>    // Hardware-specific library

bool test_3b(Adafruit_TFTLCD &tft, char* test_name);

#endif